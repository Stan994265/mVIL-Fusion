#ifndef FAST_GICP_NDT_SETTINGS_HPP
#define FAST_GICP_NDT_SETTINGS_HPP

namespace fast_gicp {

enum class NDTDistanceMode { P2D, D2D };

}  // namespace fast_gicp

#endif